#pragma once

#include "ofMain.h"
#include "ofxGui.h"
#include "ofxMaxim.h"

class ofApp : public ofBaseApp{

	public:
		void setup();
		void update();
		void draw();

		void keyPressed(int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void mouseEntered(int x, int y);
		void mouseExited(int x, int y);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);
    
    void audioRequested(float*input, int bufferSize, int nChannels);
    void audioReceived(float*input, int bufferSize, int nChannels);
    
    double outputs[2];
    double volume, waveOutput, resultingSound;
    
    ofxMaxiOsc osc, harmonics[25];
    maxiEnv envelope;
    int currentCount, initialBufferSize, sampleRate, envelopeTime;
    float fundamental, sawAmount, sineAmount, triAmount, currentNote, frequency;

    
    int x, y, change;
    float circleSize, radiusSize, circleNumber, circleSpacing, speed;
    bool motion, collect;
    
    ofxFloatSlider circleSizeControl, radiusSizeControl, circleNumberControl, circleSpacingControl, speedControl, transparencyControl;
    ofxToggle designControl, onOff;
    
    bool major, minor, majorSeventh, dominantSeventh;
};
