#include "ofApp.h"
#include "ofxGui.h"

void ofApp::setup()
{
    /* Set up the gui controls for audio and visual control. */
    
    radiusSizeControl.setup("Radius size :", 150, 0, 360);
    circleSizeControl.setup("Circle size :", 10, 0, 300);
    circleNumberControl.setup("Number of circles :", 20, 0, 260);
    circleSpacingControl.setup("Circle spacing :", 2, 0, 4);
    speedControl.setup("Speed of motion:", 0.5, 0, 5);
    transparencyControl.setup("Transparency :", 200, 0, 255);
    onOff.setup("On/ off", false);
 
    onOff.setPosition(10, 10);
    designControl.setPosition(10, 30);
    transparencyControl.setPosition(10, 50);
    radiusSizeControl.setPosition(10, 70);
    circleSizeControl.setPosition(10, 90);
    circleNumberControl.setPosition(10, 110);
    circleSpacingControl.setPosition(10, 130);
    speedControl.setPosition(10, 150);

    /* Setting the chord as major to begin with. */
    
    major = true;
    minor = false;
    majorSeventh = false;
    dominantSeventh = false;
    
    /* Setting the envelope values for the synthesis. */
    
    envelope.setAttack(1000);
    envelope.setDecay(500);
    envelope.setSustain(500);
    envelope.setRelease(1000);
    
    /* Setting motion to false so the animation is paused when the program is started. */
    
    motion = false;
    
    /* The fundamental frequency of the sound is set to 440 (pitch A) here to begin with. */
    
    fundamental = 440;
    
    sampleRate = 44100;
    initialBufferSize = 512;
    ofSoundStreamSetup(2, 0, this, sampleRate, initialBufferSize, 4);
}

void ofApp::update()
{
    /* Setting the variables for visual and audio control to that given to the gui objects.*/
    
    motion = onOff;
    radiusSize = radiusSizeControl;
    circleSize = circleSizeControl;
    circleNumber = circleNumberControl;
    circleSpacing = circleSpacingControl;
    
    /* The fundamental frequency is determined by the value given to the radiusSize variable. */
    
    fundamental = 440 * pow(2.0, ((radiusSize/30)/12.0));
    
    /* The tonality of the chord is determined by the value given in spacing the circles in the visuals. */
    
    if(circleSpacing > 0 && circleSpacing < 1)
    {
        major = true;
        minor = false;
        majorSeventh = false;
        dominantSeventh = false;
    }
    
     else if(circleSpacing > 1 && circleSpacing < 2)
    {
        minor = true;
        major = false;
        majorSeventh = false;
        dominantSeventh = false;
    }
    
    else if(circleSpacing > 2 && circleSpacing < 3)
    {
        minor = false;
        major = false;
        majorSeventh = true;
        dominantSeventh = false;
    }
    
    else if(circleSpacing > 3 || circleSpacing == 4)
    {
        minor = false;
        major = false;
        majorSeventh = false;
        dominantSeventh = true;
    }
  
    /* If the program is on, the speed is changed to cause the circular motion and the envelope is given a value determined by the speed of the motion. */
    
    if(motion == true)
    {
        speed+=speedControl;
        envelopeTime = 50 - speedControl*10;
    }
    
    /* Using current count to trigger the envelope. */
    
    currentCount++;
    
    if(currentCount > envelopeTime)
        currentCount = 0;
}


void ofApp::draw()
{
    ofSetBackgroundColor(0);
    
    /* Drawing the gui objects. */
    
    radiusSizeControl.draw();
    circleSizeControl.draw();
    circleNumberControl.draw();
    circleSpacingControl.draw();
    speedControl.draw();
    designControl.draw();
    transparencyControl.draw();
    onOff.draw();
    
    /* Drawing the visualisations. */

    for(int i = 0; i < circleNumber; i++)
    {
        x = ofGetWidth()/2 + radiusSize * cos(circleSpacing*i+speed);
        y = ofGetHeight()/2 + radiusSize * sin(circleSpacing*i+speed);
        
        ofSetColor(255, 255, 255, transparencyControl);
        ofFill();
        ofDrawCircle(x, y, circleSize);
    }
}

void ofApp::audioRequested 	(float * output, int bufferSize, int nChannels)
{
    for (int i = 0; i < bufferSize; i++)
    {
        /* Setting the volume to equal the envelope values.*/
        
        volume = envelope.adsr(1.,envelope.trigger) * (1);
        
        /* Triggering the envelope based on the currentCount.*/
        
        if(currentCount == 1)
            envelope.trigger = 1;
        
        else
            envelope.trigger = 0;
        
        /* Setting the frequencies of the sound array. The specific indexes of i they are set at are equal to degrees in a scale to create a certain chord. For example, if our fundamental is A, and we are to create a major key, setting the frequencies of the waveforms at indexes 0, 4, 7, and 12 given us A, C#, E, A. To make that minor, the second note of the chord should instead be set as the third degree and not the fourth, as shown below. These are then added to the double waveOuput to be outputted. */
        
        for(int i = 0; i < ((circleNumber)/10); i++)
        {
            if(major == true)
            {
                if(i == 0 || i == 4 || i == 7 || i == 12 || i == 16 || i == 19 || i == 24)
                    waveOutput += harmonics[i].sinewave(fundamental  * pow(2.0, (i/12.0))) * 0.1;
            }
            
            if(minor == true)
            {
                if(i == 0 || i == 3 || i == 7 || i == 12 || i == 15 || i == 19 || i == 24)
                    waveOutput += harmonics[i].sinewave(fundamental  * pow(2.0, (i/12.0))) * 0.1;
            }
            
            if(majorSeventh == true)
            {
                if(i == 0 || i == 4 || i == 7 || i == 11 || i == 16 || i == 19 || i == 23)
                    waveOutput += harmonics[i].sinewave(fundamental  * pow(2.0, (i/12.0))) * 0.1;
            }
            
            if(dominantSeventh == true)
            {
                if(i == 0 || i == 4 || i == 7 || i == 10 || i == 16 || i == 19 || i == 22)
                    waveOutput += harmonics[i].sinewave(fundamental  * pow(2.0, (i/12.0))) * 0.1;
            }
        }
        
        /* Adding a sinewave with the fundamental so we always have at least one harmonic playing.*/
        
        resultingSound = (waveOutput + osc.sinewave(fundamental)) * volume * 0.5;

        outputs[0] = resultingSound;
        outputs[1] = outputs[0];
        
        output[i*nChannels    ] = outputs[0];
        output[i*nChannels + 1] = outputs[1];
    }
}

void ofApp::audioReceived 	(float * input, int bufferSize, int nChannels)
{
    
}


void ofApp::keyPressed(int key)
{

}

void ofApp::keyReleased(int key)
{

}

void ofApp::mouseMoved(int x, int y )
{

}


void ofApp::mouseDragged(int x, int y, int button){

}


void ofApp::mousePressed(int x, int y, int button)
{

}

void ofApp::mouseReleased(int x, int y, int button)
{

}


void ofApp::mouseEntered(int x, int y)
{

}


void ofApp::mouseExited(int x, int y)
{

}


void ofApp::windowResized(int w, int h)
{

}


void ofApp::gotMessage(ofMessage msg){

}


void ofApp::dragEvent(ofDragInfo dragInfo)
{

}
