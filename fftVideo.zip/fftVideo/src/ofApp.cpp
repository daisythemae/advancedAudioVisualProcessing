#include "ofApp.h"
#include "maximilian.h"
#include "time.h"

ofApp::~ofApp()
{
    
}

void ofApp::setup()
{
    ofEnableAlphaBlending();
    ofSetupScreen();
    ofBackground(0, 0, 0);
    ofSetFrameRate(60);
    
    sampleRate 			= 44100;
    initialBufferSize	= 512;
    lAudioOut			= new float[initialBufferSize];
    rAudioOut			= new float[initialBufferSize];
    
    memset(lAudioOut, 0, initialBufferSize * sizeof(float));
    memset(rAudioOut, 0, initialBufferSize * sizeof(float));

    /* Note this file below is not saved in the data file as it is large. It is saved in the general repository on github.*/
     
    samp.load(ofToDataPath("nightmareCastle.wav"));

    fftSize = 512;
    mfft.setup(fftSize, 512, 256);
    ifft.setup(fftSize, 512, 256);
    
    /* bool variable to change whether the audio and visuals are playing.*/
     
    play = false;
    
    /* Setting up variables for the audio analysis. */
    
    nAverages = 12;
    oct.setup(sampleRate, fftSize/2, nAverages);
    mfccs = (double*) malloc(sizeof(double) * 13);
    mfcc.setup(512, 42, 13, 20, 20000, sampleRate);
    
    ofxMaxiSettings::setup(sampleRate, 2, initialBufferSize);
    
    video.load("nightmareCastle.mp4");
    
    ofSetVerticalSync(true);
    
    normalTexture.allocate(640, 360, GL_LUMINANCE);
    
    /* Pixel out to be read into the texture */
    
    pixelout = new unsigned char [640 * 360];
    
    /* Setting the volume of the video to 0 as we are using a seperate wav file to perform analysis. */
    
    video.setVolume(0);
    
    ofSoundStreamSetup(2,2, this, sampleRate, initialBufferSize, 4);
}

//--------------------------------------------------------------
void ofApp::update()
{
    /* The colour of the pixels is set to the ints R, G and B which are determined through the audio analysis below. */

    ofSetColor(R, G, B , 150);
    
    video.update();
    
    if(video.isFrameNew())
    {
        drawPixels = video.getPixels();
        
        for(int i = 0; i < 640; i++)
        {
            for(int j = 0; j < 360; j++)
            {
                /* Writing the pixels to the screen. If invert, changed depending on mouse position, is true then the pixels are inverted.*/
                
                if(invert == true)
                    pixelout[(j*640+i)] = -drawPixels[(j*640+i)];
                
                else if (invert == false)
                    pixelout[(j*640+i)] = drawPixels[(j*640+i)];
            }
        }
        
        /* Mapping the pixels to the texture. */
        
        normalTexture.loadData(pixelout, 640, 360, GL_LUMINANCE);
    }
}

//--------------------------------------------------------------
void ofApp::draw()
{
    if(play)
    {
        video.play();
        
        normalTexture.draw(0, 0, ofGetWidth(), ofGetHeight());
        
        for(int i=0; i < fftSize / 2; i++)
        {
            float height = mfft.magnitudes[i] * 100;
            
            /* Scaling the value so it sits near to 0-255 for colour.*/
            
            R = height*10000;
        }
        
        for(int i=0; i < 13; i++)
        {
            float height = mfccs[i] * 100.0;
            G = height * 10;
        }
        
        for(int i=0; i < oct.nAverages; i++)
        {
            float height = oct.averages[i] / 20.0 * 100;
            if(height * 100 > 0)
            {
                /* Scaling and adjusting so again it remains within 0-255 mostly.*/
                if(height * 100 > 255)
                    B = (height * 10)/2;
                
                else
                    B = height * 10;
            }
        }
    }
}

void ofApp::audioRequested(float * output, int bufferSize, int nChannels)
{
    for (int i = 0; i < bufferSize; i++)
    {
        if(play)
        {
            /* Setting the wave to play our sample.*/
            wave = samp.play(1.);
            
            /* Performing the fft and analysis, the values of which are used for colour control.*/
            
            if (mfft.process(wave))
            {
                mfft.magsToDB();
                oct.calculate(mfft.magnitudesDB);
                
                float sum = 0;
                float maxFreq = 0;
                int maxBin = 0;
                
                for (int i = 0; i < fftSize/2; i++)
                {
                    sum += mfft.magnitudes[i];
                    if (mfft.magnitudes[i] > maxFreq)
                    {
                        maxFreq=mfft.magnitudes[i];
                        maxBin = i;
                    }
                }
                
                mfcc.mfcc(mfft.magnitudes, mfccs);
            }
            
            outputs[0] = wave;
            outputs[1] = outputs[0];
            
            output[i*nChannels    ] = outputs[0];
            output[i*nChannels + 1] = outputs[1];
        }
    }
}

//--------------------------------------------------------------
void ofApp::audioReceived 	(float * input, int bufferSize, int nChannels)
{

    for (int i = 0; i < bufferSize; i++)
    {
    }

}

void ofApp::keyPressed(int key)
{
    /* If a key is pressed the video is paused.*/
    
    if(play == true)
    play = !play;
}

void ofApp::keyReleased(int key)
{
    
}

void ofApp::mouseMoved(int x, int y )
{
    /* IF the mouse is outside of the program size the video is paused. */
    
    if(ofGetMouseX()>0 && ofGetMouseX() < ofGetWidth() && ofGetMouseY() > 0 && ofGetMouseY() < ofGetHeight())
          play = true;
    
    else
        play = false;
    
    /* If the mouse is more than half the screen, the image is inverted. */
    
    if(ofGetMouseX()> 0 && ofGetMouseX()< ofGetWidth()/2)
        invert = false;
    
    else if(ofGetMouseX() > ofGetWidth()/2 && ofGetMouseX() < ofGetWidth())
        invert = true;
}

void ofApp::mouseDragged(int x, int y, int button)
{
    
}

void ofApp::mousePressed(int x, int y, int button)
{

}

void ofApp::mouseReleased(int x, int y, int button){
    
}

void ofApp::windowResized(int w, int h)
{
    
}

