#ifndef _OF_APP
#define _OF_APP

#include "ofMain.h"
#include "ofxMaxim.h"
#include "ofxOsc.h"
#include "ofxGui.h"

#include <sys/time.h>

#include "maxiMFCC.h"
#define HOST "localhost"
#define PORT 12345

class ofApp : public ofBaseApp{
    
public:
    ~ofApp();
    void setup();
    void update();
    void draw();
    
    void keyPressed  (int key);
    void keyReleased(int key);
    void mouseMoved(int x, int y );
    void mouseDragged(int x, int y, int button);
    void mousePressed(int x, int y, int button);
    void mouseReleased(int x, int y, int button);
    void windowResized(int w, int h);
    
    void audioRequested 	(float * ouput, int bufferSize, int nChannels);
    void audioReceived 	(float * input, int bufferSize, int nChannels);
    
    float 	* lAudioOut;
    float   * rAudioOut;
    
    float * lAudioIn;
    float * rAudioIn;
    
    int		initialBufferSize; /* buffer size */
    int		sampleRate;
    
    int change;
    
    //MAXIMILIAN STUFF:
    double wave, sample, outputs[2], ifftVal;
    maxiMix mymix;
    maxiOsc osc;
    
    ofxMaxiFFTOctaveAnalyzer oct;
    int nAverages;
    float *ifftOutput;
    int ifftSize;

    
    float peakFreq = 0;
    float centroid = 0;
    float RMS = 0;
    

    ofxMaxiIFFT ifft;
    ofxMaxiFFT mfft;
    int fftSize;
    int bins, dataSize;
    bool play;
    
    int R;
    int G;
    int B;
    
    
    float callTime;
    
    timeval callTS, callEndTS;
    
    maxiMFCC mfcc;
    double *mfccs;
    
    maxiSample samp;
    
    bool bHide, invert, lighting;
    
    ofxToggle mfccToggle;
    ofxToggle fftToggle;
    ofxToggle chromagramToggle;
    ofxToggle peakFrequencyToggle;
    ofxToggle centroidToggle;
    ofxToggle rmsToggle;
    
    
    ofPixels drawPixels;
    
    unsigned char * pixelout;
    unsigned char * trackingPixels;
    
    ofTexture normalTexture;
    
    ofxPanel gui;
    
    ofTrueTypeFont myfont;
    
    ofxOscSender sender;
    
    ofVideoPlayer video;
    
    
};

#endif
