#include "ofApp.h"
#include "ofxMaxim.h"
#include "ofxGui.h"
#include <cmath>
#include "ofxDatGui.h"

void ofApp::setup()
{
    /* Setting the colours, size and position for the keys used in the initialisation of the keyboard below the variable declarations. */
    
    black = 0;
    white = 255;
    keyboardX = 10;
    keyboardY = 330;
    keyboardSize = 125;
    
    /* The fundamental frequency is used for determining pitch below the variable declarations.*/
    
    fundamental = 440;
    
    /* Setting the default for the attack, decay, sustain and release values for the ADSR. */
    
    envelope.setAttack(1000);
    envelope.setDecay(500);
    envelope.setSustain(500);
    envelope.setRelease(1000);
    
    /* Setting up the gui objects with their labels, default minimum and maximum values and position. */
    
    /* Overall gain. */
    
    volumeControl.setup("Volume :", 10, 0, 100);
    volumeControl.setPosition(10, 10);
    
    /* Controls for envelope values for ADSR. */
    
    attack.setup("Attack (ms) : ", 500, 0, 2000);
    attack.setPosition(10, 50);
    decay.setup("Decay (ms) :", 100, 0, 2000);
    decay.setPosition(10, 70);
    sustain.setup("Sustain (ms) :", 100, 0, 2000);
    sustain.setPosition(10, 90);
    release.setup("Release (ms) :", 500, 0, 2000);
    release.setPosition(10, 110);
    
    /* Controls for the amount of different wave types in the resulting sound, added together later on.*/
    
    sine.setup("Sine amount:", 500, 0, 1000);
    sine.setPosition(10, 150);
    saw.setup("Saw amount:", 500, 0, 1000);
    saw.setPosition(10, 170);
    triangle.setup("Triangle amount:",0, 0, 1000);
    triangle.setPosition(10, 190);
    
    /* Fundamental frequency control. */
    fundamentalControl.setup("Fundamental :", 440, 1, 1000);
    fundamentalControl.setPosition(10, 230);
    
    /* Controls for the on/off, frequency and modulation index of the sine wave performing frequency modulation.*/
    
    frequencyModulation.setup(": Frequency modulation", true);
    frequencyModulation.setPosition(250, 190);
    modulatorFrequency.setup("Modulation frequency :", 2, 1, 440);
    modulatorFrequency.setPosition(250, 210);
    modulationIndex.setup("Modulation index :", 100, 1, 440);
    modulationIndex.setPosition(250, 230);
    
    /* Controls for the frequency and resonance of the sine wave performing amplitude modulation.*/
    
    amplitudeModulation.setup(": Amplitude modulation", true);
    amplitudeModulation.setPosition(250, 70);
    amplitudeFrequency.setup("AM frequency :", 100, 1, 440);
    amplitudeFrequency.setPosition(250, 90);
    
    /* Controls for the on/off and level of noise. */
    
    noiseControl.setup(": Use noise", true);
    noiseControl.setPosition(250, 10);
    noiseLevel.setup("Noise level :", 0.5, 0, 10);
    noiseLevel.setPosition(250, 30);
    
    /* Controls for on/off of the low pass filter and the amount of resonance.*/
    
    lowPass.setup(": Low pass filter", true);
    lowPass.setPosition(250, 130);
    resonance.setup("Resonance :", 10, 0, 100);
    resonance.setPosition(250, 150);
    
    /* Controls for on/off of the high pass and the cutoff.*/
    
    highPass.setup(": High pass filter", true);
    highPass.setPosition(10, 270);
    cutoffControl.setup("Cutoff :",0.1, 0, 1);
    cutoffControl.setPosition(10, 290);
 
    /* Using a for loop to load objects of the ofKey class into a keyboard array. The ofKey takes the colour of the key (determining differeing size and position of the white and black keys), the x and y position of the keyboard set above, and the overall size of the keyboard. */
    for(float i = 0.0; i < 14; i++)
    {
        keyboard.push_back(ofKey(white, keyboardX+(i*keyboardSize/4), keyboardY, keyboardSize/4, keyboardSize));
        
        /* A black key is drawn when the loop reaches certain numbers, those being the degrees on a keyboard that would have sharp notes. */
        
       if(!(i == 2) && !(i == 6) && !(i == 9) && !(i == 13))
            keyboard.push_back(ofKey(black, keyboardX+(i*keyboardSize/4)+keyboardSize/6 , keyboardY, keyboardSize/6, keyboardSize/1.7));
    }
    
    sampleRate = 44100;
    initialBufferSize = 512;
    ofSoundStreamSetup(2, 0, this, sampleRate, initialBufferSize, 4);
}


void ofApp::update()
{
    /* Updating the values of the ADSR envelope with the values given to the gui controls.*/
     
    envelope.setAttack(attack);
    envelope.setDecay(decay);
    envelope.setSustain(sustain);
    envelope.setRelease(release);
    
    /* Doing the same for the oscillators.*/
     
    sawAmount = saw;
    sineAmount = sine;
    triAmount = triangle;
    
    /* And for the fundamental frequency. Then, using a for loop to then load frequency values into the ofKey objects in the keyboard array. An expression using powers is used to calculate the frequency corresponding to the pitch of the key at that index. It uses the fundamental frequency first set to defult to 440 in setup but then controlled by the gui slider. */
    
    fundamental = fundamentalControl;
    cutoff = cutoffControl;
    
    for(int i = 0.0; i < keyboard.size(); i++)
    {
        keyboard[i].setFrequency(fundamental * pow(2.0, (i/12.0)));
    }
}

void ofApp::draw()
{
    ofSetBackgroundColor(70, 100, 50);
    
    /* Drawing the gui controls.*/
    
    volumeControl.draw();
    attack.draw();
    decay.draw();
    sustain.draw();
    release.draw();
    sine.draw();
    saw.draw();
    triangle.draw();
    fundamentalControl.draw();
    frequencyModulation.draw();
    modulatorFrequency.draw();
    modulationIndex.draw();
    amplitudeModulation.draw();
    amplitudeFrequency.draw();
    noiseControl.draw();
    noiseLevel.draw();
    lowPass.draw();
    resonance.draw();
    highPass.draw();
    cutoffControl.draw();
 
    
    /* Drawing the keyboard. Using two seperate loops so the black keys are drawn on top of the white keys.*/
    for(int i = 0; i < keyboard.size(); i++)
    {
        if(keyboard[i].noteColour.getBrightness() == 255)
        {
            keyboard[i].draw();
            //std::cout << "white notes : " << keyboard[i].noteFrequency << std::endl;
        }
    }
    
    for(int i = 0; i < keyboard.size(); i++)
    {
        if(keyboard[i].noteColour.getBrightness() == 0)
        {
            keyboard[i].draw();
            //std::cout << "black notes : " << keyboard[i].noteFrequency << std::endl;
        }
    }
}

void ofApp::audioRequested 	(float * output, int bufferSize, int nChannels)
{
    for (int i = 0; i < bufferSize; i++)
    {
        /* Setting the volume to equal the envelope values times the gain control.*/
        
        volume = envelope.adsr(1.,envelope.trigger) * (volumeControl/10);
        
        /* The bool pressed is controlled in the mousePressed() function. If it's true it triggers the envelope.*/
        
        if(pressed == true)
        {
            currentCount++;
            
            if(currentCount == 1)
                envelope.trigger = 1;
            
            else
                envelope.trigger = 0;
        }
        
        /* Turning the noiseLevel to 0 when the control is selected as off. */
        
        if(noiseControl == false)
            noiseLevel = 0;
       
        /* The default output of the synthesiser when no other changes are made.*/
        
        waveOutput = ((sineOsc.sinewave(currentNote) * volume)*sineAmount/1000) + ((sawOsc.sawn(currentNote) * volume)*sawAmount/1000) + ((triOsc.triangle(currentNote) * volume)*triAmount/1000) + ((noise.noise()*noiseLevel/10*volume)) ;
        
        /* If we are just using frequency modulation, the synthesiser output adds the sine wave to the frequency of the original waves (sine, saw and triangle).*/
        
        if(frequencyModulation == true && amplitudeModulation == false)
        {
            waveOutput = ((sineOsc.sinewave(currentNote+FM.sinewave(modulatorFrequency)*modulationIndex) * volume)*sineAmount/1000) + ((sawOsc.sawn(currentNote+FM.sinewave(modulatorFrequency)*modulationIndex) * volume)*sawAmount/1000) + ((triOsc.triangle(currentNote+FM.sinewave(modulatorFrequency)*modulationIndex) * volume)*triAmount/1000) + ((noise.noise()*noiseLevel/10*volume));
        }
        
        /* When we also have amplitude modulation selected we are multiplying it by another sinewave alongisde the frequency modulation.*/
        
        else if(frequencyModulation == true && amplitudeModulation == true)
        {
            waveOutput = (((sineOsc.sinewave(currentNote+FM.sinewave(modulatorFrequency)*modulationIndex) * volume)*sineAmount/1000)*AM.sinewave(amplitudeFrequency) + ((sawOsc.sawn(currentNote+FM.sinewave(modulatorFrequency)*modulationIndex) * volume)*sawAmount/1000)*AM.sinewave(amplitudeFrequency) + ((triOsc.triangle(currentNote+FM.sinewave(modulatorFrequency)*modulationIndex) * volume)*triAmount/1000)*AM.sinewave(amplitudeFrequency) + ((noise.noise()*noiseLevel/10*volume)));
        }
        
        /* Here we have just the amplitude modulation.*/
        
        else if(frequencyModulation == false && amplitudeModulation == true)
        {
            waveOutput = (((sineOsc.sinewave(currentNote) * volume)*sineAmount/1000)*AM.sinewave(amplitudeFrequency) + ((sawOsc.sawn(currentNote) * volume)*sawAmount/1000) * AM.sinewave(amplitudeFrequency) + ((triOsc.triangle(currentNote) * volume)*triAmount/1000)*AM.sinewave(amplitudeFrequency) + ((noise.noise()*noiseLevel/10*volume)));
        }
        
        /* Once the output of the differing waveforms is decided, we then choose whether to add filters, giving it the waveOutput signal to apply it too. */
        
        if(lowPass == true && highPass == false)
        {
            resultingSound = lowPassFilter.lores(waveOutput, volume*1000, resonance);
        }
        
        else if(lowPass == false && highPass == true)
        {
            resultingSound = highPassFilter.hipass(waveOutput, cutoff);
        }
        
        else if(lowPass == true && highPass == true)
        {
            double temp = lowPassFilter.lores(waveOutput, volume*1000, resonance);
            resultingSound = highPassFilter.hipass(temp, cutoff);
        }
        
        else
            resultingSound = waveOutput;
        
        /* The final resulting sound is then used as our output. */
        
        outputs[0] = resultingSound;
        outputs[1] = outputs[0];
        
        output[i*nChannels    ] = outputs[0];
        output[i*nChannels + 1] = outputs[1];
     }
}

void ofApp::audioReceived 	(float * input, int bufferSize, int nChannels)
{
    
}


void ofApp::keyPressed(int key)
{
    if(key == 'q')
        change+=0.1;
    
}

void ofApp::keyReleased(int key)
{
    
}


void ofApp::mouseMoved(int x, int y )
{
    /* Looping through the keyboard array to find when a note is being selected, and storing that value to be used for the synthesis when the mouse is pressed. The note() function in ofKey detects whether mouse position correlates to the key. We're also changing the colour of the key so we can see what key is being hovered over. */
    
    for(int i = 0; i < keyboard.size(); i++)
    {
        if(keyboard[i].note())
        {
            frequency = keyboard[i].noteFrequency;
            keyboard[i].selectedColour = 100;
        }
        
        else if(keyboard[i].note() == false)
        {
            keyboard[i].selectedColour = keyboard[i].noteColour;
        }
        
        std::cout << frequency << std::endl;
    }
}


void ofApp::mouseDragged(int x, int y, int button)
{

}


void ofApp::mousePressed(int x, int y, int button)
{
    /* When the mouse is actually pressed it changes the note value of the synthesiser to the once we're storing from the mouseMoved() function. */
    
    currentNote = frequency;
    
    /* Small bit of code to stop the frequency being changed when the mouse is pressed outside of the keyboard. */
    
    if(ofGetMouseX() > keyboardX && ofGetMouseX() < (keyboardX + ((keyboardSize/4)*14)) && ofGetMouseY()> keyboardY && ofGetMouseY() < keyboardY + keyboardSize)
        pressed = true;
    
    else
        pressed = false;
    
    /* Setting the currentCount back to 0 so that the envelope plays from the start with the new pitch. */
    
    currentCount = 0;
}


void ofApp::mouseReleased(int x, int y, int button)
{

}


void ofApp::mouseEntered(int x, int y)
{

}


void ofApp::mouseExited(int x, int y)
{

}

void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
