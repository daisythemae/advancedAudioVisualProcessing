#include "ofKey.h"

ofKey::ofKey(ofColor colour, int x, int y, int width, int height)
{
    /* Setting the object variables to the values given in the object creation. */
    noteX = x;
    noteY = y;
    noteWidth = width;
    noteHeight = height;
    noteColour = colour;
    selectedColour = noteColour;
}

void ofKey::draw()
{
    /* We draw the key differently depending on whether it's a white or black key. */
    
    if(noteColour.getLightness() == 255)
    {
        ofFill();
        ofSetColor(noteColour);
        ofSetColor(selectedColour);
        ofDrawRectangle(noteX, noteY, noteWidth, noteHeight);
        ofNoFill();
        ofSetColor(0);
        ofSetLineWidth(3);
        ofDrawRectangle(noteX, noteY, noteWidth, noteHeight);
    }
    
    if(noteColour.getLightness() == 0)
    {
        ofFill();
        ofSetColor(noteColour);
        ofSetColor(selectedColour);
        ofSetLineWidth(3);
        ofDrawRectangle(noteX, noteY, noteWidth, noteHeight );
        ofNoFill();
        ofSetColor(0);
        ofDrawRectangle(noteX, noteY, noteWidth, noteHeight);
    }
}

bool ofKey::note()
{
    /* This function returns true when the key is being selected. */
    if(ofGetMouseX() > noteX && ofGetMouseX() < noteX+noteWidth && ofGetMouseY() > noteY && ofGetMouseY() < noteY + noteHeight)
        return true;
}

void ofKey::setFrequency(float frequency)
{
    /* Function to set the frequency of the notes within our main setup. A seperate function is created so that */
    noteFrequency = frequency;
}
