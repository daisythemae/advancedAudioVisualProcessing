#pragma once

#include "ofMain.h"
#include "ofKey.h"
#include "ofxMaxim.h"
#include "ofxGui.h"

class ofApp : public ofBaseApp{

	public:
		void setup();
		void update();
		void draw();

		void keyPressed(int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void mouseEntered(int x, int y);
		void mouseExited(int x, int y);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);
    
    void audioRequested(float*input, int bufferSize, int nChannels);
    void audioReceived(float*input, int bufferSize, int nChannels);
    
    double outputs[2];
    double volume, waveOutput, resultingSound;
    
    maxiFilter lowPassFilter, highPassFilter;
    
    ofxMaxiOsc sineOsc, sawOsc, triOsc, FM, AM, noise;
    maxiEnv envelope;
    
    int currentCount, initialBufferSize, sampleRate, keyboardSize, keyboardX, keyboardY;
    float fundamental, sawAmount, sineAmount, triAmount, currentNote, frequency, change, cutoff;
    bool pressed;
    
    ofColor black, white;
    
    ofxFloatSlider attack, decay, sustain, release, sine, saw, triangle, modulatorFrequency, modulationIndex, noiseLevel, amplitudeFrequency, volumeControl, resonance, fundamentalControl, cutoffControl;
    ofxToggle frequencyModulation, amplitudeModulation, noiseControl, lowPass, highPass;

    vector<ofKey>keyboard;
		
};
