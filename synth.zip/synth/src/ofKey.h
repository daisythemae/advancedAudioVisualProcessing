#include "ofMain.h"

class ofKey
{
    
public:
    
    void update();
    void draw();
    void mouseReleased();
    void setFrequency(float frequency);
    bool note();
    
    int noteX, noteY, noteWidth, noteHeight, noteFrequency;
    ofColor noteColour, selectedColour;
    
    ofKey(ofColor colour, int x, int y, int width, int height);
    
private:
    
};

