#pragma once

#include "ofMain.h"
#include "ofxMaxim.h"
#include "ofxGui.h"

class ofApp : public ofBaseApp{
    
public:
    ~ofApp();
    void setup();
    void update();
    void draw();
    
    void keyPressed(int key);
    void keyReleased(int key);
    void mouseMoved(int x, int y );
    void mouseDragged(int x, int y, int button);
    void mousePressed(int x, int y, int button);
    void mouseReleased(int x, int y, int button);
    void mouseEntered(int x, int y);
    void mouseExited(int x, int y);
    void windowResized(int w, int h);
    void dragEvent(ofDragInfo dragInfo);
    void gotMessage(ofMessage msg);
    
    void audioRequested(float*input, int bufferSize, int nChannels);
    void audioReceived(float*input, int bufferSize, int nChannels);
    
    int initialBufferSize, sampleRate, fundamental, currentCount, lightnessThreshold, saturationThreshold, count, lowColour, highColour;
    float modulatorFrequency, modulationIndex, sineAmount, y, volume, x;
    bool showSettings;
    unsigned char * pixelout;
    unsigned char * lastPixels;
    double filtered, sample, freq, outputs[2];
    
    ofColor detect, trackingColour;
    
    ofVideoPlayer myMovie;
    ofVideoGrabber myGrabber;
    ofPixels normalPixels, trackingPixels;
    ofTexture normalTexture, trackingTexture;

    ofxMaxiMix mymix;
    ofxMaxiOsc osc, anotherSine;
    maxiEnv envelope;
    
    ofxToggle webcam, tracking, red, blue, green;
    ofxFloatSlider lightness, saturation;
    ofxLabel menu;
};
