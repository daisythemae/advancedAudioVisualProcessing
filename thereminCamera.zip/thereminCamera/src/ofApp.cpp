#include "ofApp.h"
#include "ofxMaxim.h"

ofApp::~ofApp()
{
    
}

void ofApp::setup()
{
    ofEnableAlphaBlending();
    ofSetupScreen();
    ofBackground(0, 0, 0);
    ofSetVerticalSync(true);
    
    sampleRate = 44100;
    initialBufferSize = 512;
    
    /* Settings the values for the envelope. */
    
    envelope.setAttack(1000);
    envelope.setDecay(500);
    envelope.setSustain(500);
    envelope.setRelease(1000);
    
    /* Setting the fundamental frequency. */

    fundamental = 440;
    
    /* Allocating the two different textures that we draw. */
    
    normalTexture.allocate(320, 240, GL_RGB);
    trackingTexture.allocate(320, 240, GL_RGB);
    
    myGrabber.listDevices();
    myGrabber.initGrabber(320, 240);
    
    pixelout = new unsigned char [320 * 240];
    
    /* Setting up the gui objects.*/
    
    menu.setup(menu, "Press space to hide menu", 10, 10);
    webcam.setup(": Show webcam", true);
    webcam.setPosition(10, 30);
    tracking.setup(": Show tracking", true);
    tracking.setPosition(10, 50);
    lightness.setup("Lightness :", 100, 0, 1000);
    lightness.setPosition(10, 70);
    saturation.setup("Saturation :", 100, 0, 1000);
    saturation.setPosition(10, 90);
    red.setup(": Track red", true);
    red.setPosition(10, 130);
    blue.setup(": Track blue", false);
    blue.setPosition(10, 150);
    green.setup(": Track green", false);
    green.setPosition(10, 170);

    showSettings = true;
    
    modulatorFrequency = 2;
    modulationIndex = 100;
    sineAmount = 500;
    
    ofSoundStreamSetup(2, 0, this, sampleRate, initialBufferSize, 4);
}

void ofApp::update()
{
    /* Setting the threshold of the lightness and the saturation to the values defined in the controls. */
    lightnessThreshold = lightness;
    saturationThreshold = saturation;
    
    myGrabber.update();
    
    
    std::cout << "highcolour   "  << highColour << "    low colour" << lowColour << std::endl;
    
    if(myGrabber.isFrameNew())
    {
        /* Setting the normalPixels array and the normalTexture to the camera input.*/
        normalPixels = myGrabber.getPixels();
        normalTexture.loadData(normalPixels);
        
      
        
        for(int i = 0; i < 320; i++)
        {
            for(int j = 0; j < 240; j++)
            {
                /* Getting the colour of the pixel at the index being looped through.*/
                detect = normalPixels.getColor((j * 320 + i) * 3);
                
                /* If it's hue angle is certain colour values determined above, the pixelout is white. Otherwise it is black. This creates the image tracking the coloured object. */
                
                if(red == true)
                {
                    if((detect.getHueAngle() > 300 || detect.getHueAngle() < 30) && (detect.getLightness() > lightnessThreshold) && (detect.getSaturation() > saturationThreshold))
                    {
                        pixelout[(j * 320 + i)] = 255;
                    }
                    else
                    {
                        pixelout[(j * 320 + i)] = 0;
                    }
                }
                
                if(green == true)
                {
                    if((detect.getHueAngle() > 75 && detect.getHueAngle() < 140) && (detect.getLightness() > lightnessThreshold) && (detect.getSaturation() > saturationThreshold))
                    {
                        pixelout[(j * 320 + i)] = 255;
                    }
                    else
                    {
                        pixelout[(j * 320 + i)] = 0;
                    }
                }
            
                  if(blue == true)
                {
                    if((detect.getHueAngle() > 150 && detect.getHueAngle() < 270) && (detect.getLightness() > lightnessThreshold) && (detect.getSaturation() > saturationThreshold))
                    {
                        pixelout[(j * 320 + i)] = 255;
                    }
                    
                    else
                    {
                        pixelout[(j * 320 + i)] = 0;
                    }
                   
                }
            }
        }
        
        /* We're then giving these pixels to the texture to be drawn. */
        
        trackingTexture.loadData(pixelout, 320, 240, GL_LUMINANCE);
        trackingTexture.readToPixels(trackingPixels);
        
        for(int i = 0; i < 320; i++)
        {
            for(int j = 0; j < 240; j++)
            {
                /* We're then analysis the output of the red detection to create sound. If the pixel is white, the the frequency is changed.*/
                
                trackingColour = trackingPixels.getColor((j * 320 + i) * 3);
                
                if(trackingColour.getBrightness() == 255)
                {
                    y = (j * 320 + i)/ofGetWidth();
                    
                    if(y > 0 && y < 5)
                    {
                        if(freq > fundamental)
                            freq--;
                    }

                    
                    else if(y > 5 && y < 10)
                    {
                        /* Using if statements to slide between frequencies.*/
                        
                        if(freq > (fundamental * pow(2.0, 2/12.0)))
                            freq--;
                        
                        else if(freq > (fundamental *pow(2.0, 2/12.0)))
                            freq++;
                    }
                    
                    
                    else if(y > 10 && y < 15)
                    {
                        if(freq > (fundamental *pow(2.0, 3/12.0)))
                            freq--;
                        
                        else if(freq < (fundamental *pow(2.0, 3/12.0)))
                            freq++;
                    }
                    
                    else if(y > 15 && y < 20)
                    {
                        if(freq > (fundamental *pow(2.0, 4/12.0)))
                            freq--;
                        
                        else if(freq < (fundamental *pow(2.0, 4/12.0)))
                            freq++;
                    }
                    
                    
                    else if(y > 20 && y < 25)
                    {
                        if(freq > (fundamental *pow(2.0, 5/12.0)))
                            freq--;
                        
                        else if(freq < (fundamental *pow(2.0, 5/12.0)))
                            freq++;
                    }
                    
                    
                    else if(y > 25 && y < 30)
                    {
                        if(freq > (fundamental *pow(2.0, 6/12.0)))
                            freq--;
                        
                        else if(freq < (fundamental *pow(2.0, 6/12.0)))
                            freq++;
                    }
                    
                    
                    else if(y > 30 && y < 35)
                    {
                        if(freq > (fundamental *pow(2.0, 7/12.0)))
                            freq--;
                        
                        else if(freq < (fundamental *pow(2.0, 7/12.0)))
                            freq++;
                    }
                    
                    
                    else if(y > 35 && y < 40)
                    {
                        if(freq > (fundamental *pow(2.0, 8/12.0)))
                            freq--;
                        
                        else if(freq < (fundamental *pow(2.0, 8/12.0)))
                            freq++;
                    }
                    
                    
                    else if(y > 40 && y < 45)
                    {
                        if(freq > (fundamental *pow(2.0, 9/12.0)))
                            freq--;
                        
                        else if(freq < (fundamental *pow(2.0, 9/12.0)))
                            freq++;
                    }
                    
                    else if(y > 45 && y < 50)
                    {
                        if(freq > (fundamental *pow(2.0, 10/12.0)))
                            freq--;
                        
                        else if(freq < (fundamental *pow(2.0, 10/12.0)))
                            freq++;
                    }
                    
                    else if(y > 50 && y < 55)
                    {
                        if(freq > (fundamental *pow(2.0, 11/12.0)))
                            freq--;
                        
                        else if(freq < (fundamental *pow(2.0, 11/12.0)))
                            freq++;
                    }
                    
                    
                    else if(y > 55 && y < 65)
                    {
                        if(freq > (fundamental *pow(2.0, 12/12.0)))
                            freq--;
                        
                        else if(freq < (fundamental *pow(2.0, 12/12.0)))
                            freq++;
                    }
                }
            }
        }
    }
}


void ofApp::draw()
{
    ofSetColor(255, 255, 255, 255);
    
    /* Using gui to control which screen is showing and what texture is being drawn.*/
    
    if(webcam == true && tracking == false)
        normalTexture.draw(0, 0, ofGetWidth(), ofGetHeight());
    
    if(tracking == true && webcam == false)
        trackingTexture.draw(0, 0, ofGetWidth(), ofGetHeight());
    
    if(tracking == true && webcam == true)
    {
        normalTexture.draw(0, ofGetHeight()/2-ofGetHeight()/4,  ofGetWidth()/2, ofGetHeight()/2);
        trackingTexture.draw(ofGetWidth()/2, ofGetHeight()/2-ofGetHeight()/4, ofGetWidth()/2, ofGetHeight()/2);
    }
    
    /* Using current count to control the envelope.*/
    
    currentCount++;
    
    if(currentCount > 20)
        currentCount = 0;
    
    if(showSettings)
    {
        menu.draw();
        webcam.draw();
        tracking.draw();
        lightness.draw();
        saturation.draw();
        red.draw();
        green.draw();
        blue.draw();
    }
}

void ofApp::audioRequested(float * output, int bufferSize, int nChannels)
{
    for (int i = 0; i < bufferSize; i++)
    {
        /* Creating the ADSR envelope for the sound. */
        volume = envelope.adsr(1.,envelope.trigger) * 1;
        
        if(currentCount == 1)
            envelope.trigger = 1;
        
        else
            envelope.trigger = 0;
        
        /* Using FM synthesis to create the theremin sound. */
        
        outputs[0] = (osc.sinewave(freq+anotherSine.sinewave(modulatorFrequency)*modulationIndex)) * volume * 0.5;
        outputs[1] = outputs[0];
        
        output[i*nChannels    ] = outputs[0];
        output[i*nChannels + 1] = outputs[1];
    }
}

void ofApp::audioReceived(float * input, int bufferSize, int nChannels)
{
    
    
}

void ofApp::keyPressed(int key)
{
    if(key == ' ')
        showSettings = !showSettings;
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key)
{
    
    
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y )
{
    
}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button)
{
    
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){
    
}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){
    
}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){
    
}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){
    
}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){
    
}
