#include "ofApp.h"

void ofApp::setup()
{
    ofEnableAlphaBlending();
    ofSetupScreen();
    ofBackground(0, 0, 0);
    ofSetVerticalSync(true);
    myTexture.allocate(640, 480, GL_RGB);
    
    /* Defining the array for the new pixels to be outputted. */
    
    pixelout = new unsigned char [640*480];

    myMovie.load("flowering.mp4");
    
    /* Setting the video to play once the code runs.*/
    
    myMovie.play();
    
    /* The change variable effects the 'phase' of the pixels across the screen.*/
    
    change = 1;
}

void ofApp::update()
{
    myMovie.update();
    
    /* Using isFrameNew so the following code only runs when the frame of the video is different to that of the last.*/
    
    if(myMovie.isFrameNew())
    {
        myPixels = myMovie.getPixels();
        
        /* Looping through the pixel array to changle individual pixels. */
        
        for(int i = 0; i < myPixels.size(); i++)
        {
            /* Creating a random integer between 0 and the size of the array. */
            
            int randomPixel = ofRandom(0, myPixels.size()-1);
            
            /* We then assign individual pixels new values. We take the pixel of the index decided by the randomPixel, and make it equal to that of the pixel of the index (randomPixel+change)/2. Adding the change value here gets us the value of a pixel further into the array. Change is determined by the x position of the mouse, so as it increments the image appears to phase out of sync with itself. We're using a if statement here so that it doesn't try to assign the value of an pixel index outside of the array bounds. */
             
             
            if((randomPixel+(1*change)) > myPixels.size()-1)
                myPixels[randomPixel] = myPixels[(randomPixel+change)/2];
            
            else
                myPixels[randomPixel] = myPixels[randomPixel+(change)];
            
            /* Updating the value of change with the position of mouse x, only when the mouse is within the program. */
            
            if(ofGetMouseX() > 0 && ofGetMouseX() < ofGetWidth())
                change = ofGetMouseX();
        }
        
        /* Loading the data from pixel array into the texture to be drawn. */
        
        myTexture.loadData(myPixels);
        
    }
}


void ofApp::draw()
{
    myTexture.draw(0, 0, ofGetWidth(), ofGetHeight());
}


void ofApp::keyPressed(int key)
{
    std::cout << myMovie.getSpeed() << std::endl;
}

void ofApp::keyReleased(int key)
{
    
}


void ofApp::mouseMoved(int x, int y)
{
    /* Adjusting playback speed of the movie with the y position of the mouse. */
    
    myMouseY = ofGetMouseY();
    division = myMouseY/3/100;
    myMovie.setSpeed(division);
}


void ofApp::mouseDragged(int x, int y, int button)
{
    
}


void ofApp::mousePressed(int x, int y, int button)
{

}


void ofApp::mouseReleased(int x, int y, int button)
{
    
}


void ofApp::mouseEntered(int x, int y)
{
    
}


void ofApp::mouseExited(int x, int y)
{
    
}


void ofApp::windowResized(int w, int h)
{
    
}

void ofApp::gotMessage(ofMessage msg)
{
    
}


void ofApp::dragEvent(ofDragInfo dragInfo)
{
    
}
